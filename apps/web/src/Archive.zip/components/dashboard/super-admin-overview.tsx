"use client";

import { useEffect, useState } from "react";

import { apiClient } from "@/lib/api-client";
import { Usage } from "@/lib/types";

export function SuperAdminOverview() {
  const [counts, setCounts] = useState({
    organizations: 0,
    users: 0,
    packages: 0,
    scans: 0
  });
  const [usage, setUsage] = useState<Usage[]>([]);

  useEffect(() => {
    async function loadCounts() {
      const [organizations, users, packages, scans, usageRows] = await Promise.all([
        apiClient.listOrganizations(),
        apiClient.listUsers(),
        apiClient.listPackages(),
        apiClient.listScans(),
        apiClient.listOrganizationUsage()
      ]);
      setCounts({
        organizations: organizations.length,
        users: users.length,
        packages: packages.length,
        scans: scans.length
      });
      setUsage(usageRows);
    }

    void loadCounts();
  }, []);

  return (
    <section className="space-y-6">
      <div className="grid gap-4 md:grid-cols-4">
        {Object.entries(counts).map(([label, value]) => (
          <div
            key={label}
            className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6"
          >
            <p className="text-sm uppercase tracking-[0.2em] text-cyan-300">
              {label}
            </p>
            <p className="mt-4 text-3xl font-semibold text-white">{value}</p>
          </div>
        ))}
      </div>

      <div className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6">
        <p className="text-sm font-medium text-white">Organization usage</p>
        <div className="mt-4 overflow-x-auto">
          <table className="min-w-full divide-y divide-white/10 text-left text-sm">
            <thead className="text-xs uppercase tracking-[0.2em] text-slate-400">
              <tr>
                <th className="px-4 py-3 font-medium">Organization</th>
                <th className="px-4 py-3 font-medium">Package</th>
                <th className="px-4 py-3 font-medium">Used This Week</th>
                <th className="px-4 py-3 font-medium">Limit</th>
                <th className="px-4 py-3 font-medium">Remaining</th>
                <th className="px-4 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10 text-slate-200">
              {usage.map((row) => (
                <tr key={row.organization_id}>
                  <td className="px-4 py-4 font-medium text-white">
                    {row.organization_name}
                  </td>
                  <td className="px-4 py-4 text-slate-300">
                    {row.package_name ?? "No package"}
                  </td>
                  <td className="px-4 py-4">{row.scans_used_this_week}</td>
                  <td className="px-4 py-4">{row.scan_limit_per_week}</td>
                  <td className="px-4 py-4">{row.scans_remaining_this_week}</td>
                  <td className="px-4 py-4 text-slate-300">{row.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
