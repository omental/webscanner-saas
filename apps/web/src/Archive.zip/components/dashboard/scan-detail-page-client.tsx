"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";

import { apiClient } from "@/lib/api-client";
import { Scan, Target } from "@/lib/types";
import { ScanProgressPanel } from "@/components/dashboard/scan-progress-panel";
import { AiReportSection } from "@/components/dashboard/ai-report-section";
import { AuditDashboard, FindingsList, PagesList, TechnologyGrid } from "@/components/dashboard/scan-detail-sections";
import { useToast } from "@/components/ui/toast-provider";
import { Button } from "@/components/ui/button";

type ScanDetailPageClientProps = {
  scanId: number;
  initialScan?: Scan;
  initialTarget?: Target;
};

const activeStatuses = new Set(["queued", "pending", "running"]);
const stoppableStatuses = new Set(["queued", "running"]);

export function ScanDetailPageClient({
  scanId,
  initialScan,
  initialTarget
}: ScanDetailPageClientProps) {
  const { showToast } = useToast();
  const [scan, setScan] = useState<Scan | null>(initialScan || null);
  const [target, setTarget] = useState<Target | null>(initialTarget || null);
  const [loading, setLoading] = useState(!initialScan);
  const [cancelling, setCancelling] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pollingEnabled, setPollingEnabled] = useState(
    initialScan ? activeStatuses.has(initialScan.status.toLowerCase()) : false
  );
  const previousScanRef = useRef<Scan | null>(initialScan || null);

  useEffect(() => {
    if (!initialScan || !initialTarget) {
      const loadData = async () => {
        try {
          setLoading(true);
          const s = await apiClient.getScan(scanId);
          const ts = await apiClient.listTargets();
          const t = ts.find(item => item.id === s.target_id);
          setScan(s);
          setTarget(t || null);
          setPollingEnabled(activeStatuses.has(s.status.toLowerCase()));
          previousScanRef.current = s;
        } catch {
          setError("Failed to load scan details.");
        } finally {
          setLoading(false);
        }
      };
      void loadData();
    }
  }, [scanId, initialScan, initialTarget]);

  async function refresh(showRefreshState = true) {
    if (!scan) return;
    try {
      if (showRefreshState) {
        setLoading(true);
      }
      setError(null);
      const nextScan = await apiClient.getScan(scan.id);

      const status = nextScan.status.toLowerCase();
      const previousStatus = previousScanRef.current?.status.toLowerCase();

      if (previousStatus && previousStatus !== status && status === "completed") {
        showToast(`Scan #${scan.id} completed.`, "success");
      }
      if (previousStatus && previousStatus !== status && status === "failed") {
        showToast(`Scan #${scan.id} failed.`, "error");
      }
      if (previousStatus && previousStatus !== status && status === "cancelled") {
        showToast("Scan cancelled", "info");
      }

      setScan(nextScan);
      previousScanRef.current = nextScan;
      setPollingEnabled(activeStatuses.has(status));
    } catch {
      setError("Unable to refresh scan details.");
    } finally {
      if (showRefreshState) {
        setLoading(false);
      }
    }
  }

  async function handleCancelScan() {
    if (!scan) return;
    try {
      setError(null);
      setCancelling(true);
      const cancelledScan = await apiClient.cancelScan(scan.id);
      setScan(cancelledScan);
      previousScanRef.current = cancelledScan;
      setPollingEnabled(false);
      showToast("Scan cancelled", "info");
    } catch (cancelError) {
      setError(
        cancelError instanceof Error ? cancelError.message : "Unable to cancel scan."
      );
    } finally {
      setCancelling(false);
    }
  }

  useEffect(() => {
    if (!pollingEnabled || !scan) {
      return undefined;
    }

    const interval = window.setInterval(() => {
      void refresh(false);
    }, 3000);

    return () => window.clearInterval(interval);
  }, [pollingEnabled, scan]);

  if (loading && !scan) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="flex items-center gap-3 text-slate-500">
           <svg className="h-5 w-5 animate-spin text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
          <span className="text-sm font-medium">Loading scan details...</span>
        </div>
      </div>
    );
  }

  if (!scan || !target) {
    return (
      <div className="rounded-2xl border border-rose-200 bg-rose-50 p-8 text-center">
        <p className="font-semibold text-rose-700">Scan or target not found.</p>
        <Link href="/dashboard/scans" className="mt-4 inline-block text-sm font-medium text-rose-600 hover:underline">
          Return to scans
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-wrap items-center justify-between gap-6">
        <div>
          <Link
            href="/dashboard/scans"
            className="flex items-center gap-2 text-sm font-medium text-slate-500 transition hover:text-indigo-600"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
              className="h-4 w-4"
            >
              <path
                fillRule="evenodd"
                d="M17 10a.75.75 0 0 1-.75.75H5.612l4.158 3.96a.75.75 0 1 1-1.04 1.08l-5.5-5.25a.75.75 0 0 1 0-1.08l5.5-5.25a.75.75 0 1 1 1.04 1.08L5.612 9.25H16.25A.75.75 0 0 1 17 10Z"
                clipRule="evenodd"
              />
            </svg>
            Back to Scans
          </Link>
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900">
              Scan #{scan.id}
            </h2>
            <div className="flex items-center gap-3">
              {stoppableStatuses.has(scan.status.toLowerCase()) ? (
                <Button
                  variant="outline"
                  onClick={() => void handleCancelScan()}
                  disabled={cancelling}
                  className="border-rose-200 text-rose-600 hover:bg-rose-50 hover:text-rose-700"
                >
                  {cancelling ? "Stopping..." : "Stop Scan"}
                </Button>
              ) : null}
              <Button variant="secondary" onClick={() => void refresh()}>
                {loading ? "Updating..." : "Refresh Results"}
              </Button>
            </div>
          </div>
          <p className="mt-2 text-slate-500">
            Target: <span className="font-semibold text-indigo-600">{target.base_url}</span>
          </p>
        </div>
      </div>

      {error ? (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm font-medium text-rose-700">
          {error}
        </div>
      ) : null}

      <ScanProgressPanel
        scan={scan}
        targetLabel={target.normalized_domain}
      />

      {/* AI Report Section */}
      <AiReportSection
        scanId={scan.id}
        scanStatus={scan.status}
      />

      <div className="space-y-12">
        <AuditDashboard scan={scan} />
        <TechnologyGrid scan={scan} />
        <FindingsList scan={scan} />
        <PagesList scan={scan} />
      </div>
    </div>
  );
}
