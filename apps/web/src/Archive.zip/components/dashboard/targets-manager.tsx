"use client";

import { FormEvent, useEffect, useState } from "react";

import { apiClient } from "@/lib/api-client";
import { Target } from "@/lib/types";
import { getSessionUser, SessionUser } from "@/lib/session";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/toast-provider";

export function TargetsManager() {
  const { showToast } = useToast();
  const [sessionUser, setSessionUser] = useState<SessionUser | null>(null);
  const [targets, setTargets] = useState<Target[]>([]);
  const [baseUrl, setBaseUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadTargets() {
    try {
      setLoading(true);
      setError(null);
      const data = await apiClient.listTargets();
      setTargets(data);
    } catch {
      setError("Unable to load targets right now.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    setSessionUser(getSessionUser());
    void loadTargets();
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      setSubmitting(true);
      setError(null);
      await apiClient.createTarget({
        user_id: sessionUser?.id ?? 1,
        base_url: baseUrl
      });
      setBaseUrl("");
      showToast("Target created.", "success");
      await loadTargets();
    } catch {
      setError("Unable to create target.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <section className="space-y-6">
      <div className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6">
        <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">
          Targets
        </p>
        <h3 className="mt-4 text-2xl font-semibold text-white">
          Target Inventory
        </h3>
        <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-300">
          Review saved targets. Admins can add new targets for future scans.
        </p>
      </div>

      {sessionUser?.role === "admin" ? (
      <div className="rounded-[1.75rem] border border-white/10 bg-slate-950/70 p-6">
        <form className="space-y-4" onSubmit={handleSubmit}>
          <Input
            label="Base URL"
            placeholder="https://example.com"
            value={baseUrl}
            onChange={(event) => setBaseUrl(event.target.value)}
            required
          />
          <div className="flex items-center gap-3">
            <Button type="submit" disabled={submitting}>
              {submitting ? "Creating..." : "Create target"}
            </Button>
            {error ? <p className="text-sm text-rose-300">{error}</p> : null}
          </div>
        </form>
      </div>
      ) : null}

      <div className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6">
        <div className="flex items-center justify-between gap-4">
          <p className="text-sm font-medium text-white">Saved targets</p>
          <Button variant="secondary" onClick={() => void loadTargets()}>
            Refresh
          </Button>
        </div>

        {loading ? (
          <p className="mt-4 text-sm text-slate-400">Loading targets...</p>
        ) : error && targets.length === 0 ? (
          <p className="mt-4 text-sm text-rose-300">{error}</p>
        ) : targets.length === 0 ? (
          <p className="mt-4 text-sm text-slate-400">
            No targets yet.
          </p>
        ) : (
          <div className="mt-4 space-y-3">
            {targets.map((target) => (
              <div
                key={target.id}
                className="rounded-2xl border border-white/10 bg-slate-950/70 p-4"
              >
                <p className="font-medium text-white">{target.base_url}</p>
                <p className="mt-1 text-sm text-slate-400">
                  Domain: {target.normalized_domain}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
