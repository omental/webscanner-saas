"use client";

import { useState } from "react";

import { Organization, User } from "@/lib/types";
import { getSessionUser, isSuperAdmin } from "@/lib/session";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type UsersTableProps = {
  users: User[];
  loading: boolean;
  error: string | null;
  onRefresh: () => void | Promise<void>;
  onUpdateUser: (
    userId: number,
    payload: {
      name?: string;
      email?: string;
      password?: string;
      role?: string;
      organization_id?: number | null;
      status?: string;
    }
  ) => void | Promise<void>;
  onDeleteUser: (userId: number) => void | Promise<void>;
  organizations: Organization[];
};

function statusTone(status: string) {
  if (status.toLowerCase() === "active") {
    return "success";
  }

  return "warning";
}

export function UsersTable({
  users,
  loading,
  error,
  onRefresh,
  onUpdateUser,
  onDeleteUser,
  organizations
}: UsersTableProps) {
  const [editingUserId, setEditingUserId] = useState<number | null>(null);
  const [drafts, setDrafts] = useState<
    Record<
      number,
      {
        name: string;
        email: string;
        role: string;
        status: string;
        password: string;
        organization_id: string;
      }
    >
  >({});
  const [rowError, setRowError] = useState<string | null>(null);
  const sessionUser = getSessionUser();
  const superAdmin = isSuperAdmin(sessionUser);

  function draftFor(user: User) {
    return (
      drafts[user.id] ?? {
        name: user.name,
        email: user.email,
        role: user.role,
        status: user.status,
        password: "",
        organization_id: user.organization_id?.toString() ?? ""
      }
    );
  }

  function updateDraft(
    user: User,
    field: "name" | "email" | "role" | "status" | "password" | "organization_id",
    value: string
  ) {
    setDrafts((current) => ({
      ...current,
      [user.id]: {
        ...draftFor(user),
        [field]: value
      }
    }));
  }

  async function saveUser(user: User) {
    const draft = draftFor(user);
    try {
      setRowError(null);
      await onUpdateUser(user.id, {
        name: draft.name,
        email: draft.email,
        role: draft.role,
        organization_id:
          superAdmin && draft.role !== "super_admin"
            ? Number(draft.organization_id)
            : draft.role === "super_admin"
              ? null
              : undefined,
        status: draft.status,
        ...(draft.password ? { password: draft.password } : {})
      });
      setEditingUserId(null);
      setDrafts((current) => {
        const next = { ...current };
        delete next[user.id];
        return next;
      });
    } catch {
      setRowError("Unable to update user.");
    }
  }

  async function removeUser(user: User) {
    try {
      setRowError(null);
      await onDeleteUser(user.id);
    } catch {
      setRowError("Unable to delete user. Remove related targets or scans first.");
    }
  }

  return (
    <div className="overflow-hidden rounded-[1.75rem] border border-white/10 bg-white/5">
      <div className="flex flex-col gap-4 border-b border-white/10 px-6 py-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm font-medium text-white">Team members</p>
          <p className="mt-1 text-sm text-slate-400">
            Admins can update roles, status, names, and reset passwords.
          </p>
        </div>
        <Button variant="secondary" onClick={() => void onRefresh()}>
          Refresh
        </Button>
      </div>

      {loading ? (
        <p className="px-6 py-5 text-sm text-slate-400">Loading users...</p>
      ) : error ? (
        <p className="px-6 py-5 text-sm text-rose-300">{error}</p>
      ) : users.length === 0 ? (
        <p className="px-6 py-5 text-sm text-slate-400">No users yet.</p>
      ) : (
        <>
        {rowError ? (
          <p className="px-6 pt-5 text-sm text-rose-300">{rowError}</p>
        ) : null}
        <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-white/10 text-left">
          <thead className="bg-slate-950/40 text-xs uppercase tracking-[0.2em] text-slate-400">
            <tr>
              <th className="px-6 py-4 font-medium">Name</th>
              <th className="px-6 py-4 font-medium">Email</th>
              {superAdmin ? (
                <th className="px-6 py-4 font-medium">Organization</th>
              ) : null}
              <th className="px-6 py-4 font-medium">Role</th>
              <th className="px-6 py-4 font-medium">Status</th>
              <th className="px-6 py-4 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/10">
            {users.map((user) => {
              const editing = editingUserId === user.id;
              const draft = draftFor(user);
              const canManageUser = superAdmin || user.role === "team_member";

              return (
              <tr key={user.email} className="text-sm text-slate-200">
                <td className="px-6 py-4 font-medium text-white">
                  {editing ? (
                    <input
                      className="w-48 rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400"
                      value={draft.name}
                      onChange={(event) => updateDraft(user, "name", event.target.value)}
                    />
                  ) : (
                    user.name
                  )}
                </td>
                <td className="px-6 py-4 text-slate-300">
                  {editing ? (
                    <input
                      className="w-56 rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400"
                      type="email"
                      value={draft.email}
                      onChange={(event) =>
                        updateDraft(user, "email", event.target.value)
                      }
                    />
                  ) : (
                    user.email
                  )}
                </td>
                {superAdmin ? (
                  <td className="px-6 py-4 text-slate-300">
                    {editing && draft.role !== "super_admin" ? (
                      <select
                        className="rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400"
                        value={draft.organization_id}
                        onChange={(event) =>
                          updateDraft(user, "organization_id", event.target.value)
                        }
                      >
                        <option value="">Choose organization</option>
                        {organizations.map((organization) => (
                          <option key={organization.id} value={organization.id}>
                            {organization.name}
                          </option>
                        ))}
                      </select>
                    ) : (
                      user.organization_name ?? "Platform"
                    )}
                  </td>
                ) : null}
                <td className="px-6 py-4">
                  {editing ? (
                    <select
                      className="rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400"
                      value={draft.role}
                      onChange={(event) => updateDraft(user, "role", event.target.value)}
                    >
                      {superAdmin ? <option value="admin">Admin</option> : null}
                      <option value="team_member">Team member</option>
                      {superAdmin ? (
                        <option value="super_admin">Super admin</option>
                      ) : null}
                    </select>
                  ) : (
                    user.role === "super_admin"
                      ? "Super admin"
                      : user.role === "admin"
                        ? "Admin"
                        : "Team member"
                  )}
                </td>
                <td className="px-6 py-4">
                  {editing ? (
                    <select
                      className="rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white outline-none focus:border-cyan-400"
                      value={draft.status}
                      onChange={(event) => updateDraft(user, "status", event.target.value)}
                    >
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                    </select>
                  ) : (
                    <Badge tone={statusTone(user.status)}>{user.status}</Badge>
                  )}
                </td>
                <td className="relative px-6 py-4">
                  {editing ? (
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        className="w-40 rounded-xl border border-white/10 bg-slate-950 px-3 py-2 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-400"
                        type="password"
                        placeholder="New password"
                        value={draft.password}
                        onChange={(event) =>
                          updateDraft(user, "password", event.target.value)
                        }
                      />
                      <Button className="px-3 py-2" onClick={() => void saveUser(user)}>
                        Save
                      </Button>
                      <Button
                        variant="secondary"
                        className="px-3 py-2"
                        onClick={() => setEditingUserId(null)}
                      >
                        Cancel
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-wrap items-center gap-2">
                      <Button
                        variant="secondary"
                        className="px-3 py-2"
                        onClick={() => setEditingUserId(user.id)}
                        disabled={!canManageUser}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="ghost"
                        className="px-3 py-2 text-rose-200 hover:text-rose-100"
                        onClick={() => void removeUser(user)}
                        disabled={!canManageUser}
                      >
                        Delete
                      </Button>
                    </div>
                  )}
                </td>
              </tr>
            );
            })}
          </tbody>
        </table>
        </div>
        </>
      )}
    </div>
  );
}
