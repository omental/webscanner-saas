"use client";

import React, { useCallback, useEffect, useState } from "react";
import { buildApiUrl } from "@/lib/api-client";

type AiReportSectionProps = {
  scanId: number;
  scanStatus: string;
};

type AiReportResponse = {
  report_id: number;
  scan_id: number;
  model: string;
  report_text: string;
  download_url: string;
  generated_at: string;
};

type ReportHistoryItem = {
  id: number;
  scan_id: number;
  model: string;
  status: string;
  created_at: string | null;
  download_url: string;
  has_pdf: boolean;
};

/* ------------------------------------------------------------------ */
/*  Lightweight Markdown-ish renderer                                  */
/* ------------------------------------------------------------------ */

function renderMarkdownLine(line: string, index: number) {
  if (line.startsWith("##### ")) {
    return (
      <h5 key={index} className="mb-2 mt-5 text-sm font-bold text-indigo-900">
        {renderInlineMarkdown(line.slice(6))}
      </h5>
    );
  }
  if (line.startsWith("#### ")) {
    return (
      <h4 key={index} className="mb-2 mt-5 text-sm font-bold text-slate-900">
        {renderInlineMarkdown(line.slice(5))}
      </h4>
    );
  }
  if (line.startsWith("### ")) {
    return (
      <h3 key={index} className="mb-2 mt-6 text-base font-bold text-slate-900">
        {renderInlineMarkdown(line.slice(4))}
      </h3>
    );
  }
  if (line.startsWith("## ")) {
    return (
      <h2 key={index} className="mb-3 mt-8 border-b border-slate-100 pb-2 text-lg font-bold text-slate-900">
        {renderInlineMarkdown(line.slice(3))}
      </h2>
    );
  }
  if (line.startsWith("# ")) {
    return (
      <h1 key={index} className="mb-4 mt-8 text-xl font-bold text-slate-900">
        {renderInlineMarkdown(line.slice(2))}
      </h1>
    );
  }

  if (/^[-*_]{3,}\s*$/.test(line)) {
    return <hr key={index} className="my-6 border-slate-100" />;
  }

  if (/^\s*[-*+]\s/.test(line)) {
    const content = line.replace(/^\s*[-*+]\s/, "");
    return (
      <li key={index} className="ml-5 list-disc text-sm leading-7 text-slate-600">
        {renderInlineMarkdown(content)}
      </li>
    );
  }

  if (/^\s*\d+[.)]\s/.test(line)) {
    const content = line.replace(/^\s*\d+[.)]\s/, "");
    return (
      <li key={index} className="ml-5 list-decimal text-sm leading-7 text-slate-600">
        {renderInlineMarkdown(content)}
      </li>
    );
  }

  if (line.trim() === "") {
    return <div key={index} className="h-2" />;
  }

  return (
    <p key={index} className="text-sm leading-7 text-slate-600">
      {renderInlineMarkdown(line)}
    </p>
  );
}

function renderInlineMarkdown(text: string) {
  const parts: (string | React.ReactElement)[] = [];
  const regex = /\*\*(.+?)\*\*|\*(.+?)\*|`(.+?)`|\[(.+?)\]\((.+?)\)/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;
  let key = 0;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(text.slice(lastIndex, match.index));
    }

    if (match[1] !== undefined) {
      parts.push(
        <strong key={key++} className="font-bold text-slate-900">
          {match[1]}
        </strong>
      );
    } else if (match[2] !== undefined) {
      parts.push(
        <em key={key++} className="text-slate-800">
          {match[2]}
        </em>
      );
    } else if (match[3] !== undefined) {
      parts.push(
        <code key={key++} className="rounded bg-slate-100 px-1.5 py-0.5 text-xs font-medium text-indigo-700">
          {match[3]}
        </code>
      );
    } else if (match[4] !== undefined && match[5] !== undefined) {
      parts.push(
        <a
          key={key++}
          href={match[5]}
          target="_blank"
          rel="noreferrer"
          className="text-indigo-600 font-semibold underline decoration-indigo-200 underline-offset-4 transition hover:text-indigo-700"
        >
          {match[4]}
        </a>
      );
    }

    lastIndex = regex.lastIndex;
  }

  if (lastIndex < text.length) {
    parts.push(text.slice(lastIndex));
  }

  return parts;
}

function RenderedReport({ text }: { text: string }) {
  const lines = text.split("\n");
  return (
    <div className="report-content">
      {lines.map((line, idx) => renderMarkdownLine(line, idx))}
    </div>
  );
}

function Spinner() {
  return (
    <svg
      className="h-4 w-4 animate-spin"
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
    >
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
    </svg>
  );
}

export function AiReportSection({ scanId, scanStatus }: AiReportSectionProps) {
  const [reportText, setReportText] = useState<string | null>(null);
  const [generatedAt, setGeneratedAt] = useState<string | null>(null);
  const [modelName, setModelName] = useState<string | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [history, setHistory] = useState<ReportHistoryItem[]>([]);
  const [selectedReportId, setSelectedReportId] = useState<number | null>(null);

  const fetchHistory = useCallback(async () => {
    try {
      const res = await fetch(buildApiUrl(`/scans/${scanId}/reports`), {
        headers: { "X-Current-User-Id": "1" }
      });
      if (res.ok) {
        const data = (await res.json()) as ReportHistoryItem[];
        setHistory(data);
      }
    } catch {
      // ignore
    }
  }, [scanId]);

  const fetchLatestReport = useCallback(async () => {
    try {
      const res = await fetch(buildApiUrl(`/scans/${scanId}/reports/latest`), {
        headers: { "X-Current-User-Id": "1" }
      });
      if (res.ok) {
        const data = (await res.json()) as AiReportResponse;
        setReportText(data.report_text);
        setGeneratedAt(data.generated_at);
        setModelName(data.model);
        setDownloadUrl(data.download_url);
        setSelectedReportId(data.report_id);
      }
    } catch {
      // ignore
    }
  }, [scanId]);

  useEffect(() => {
    void fetchHistory();
    void fetchLatestReport();
  }, [fetchHistory, fetchLatestReport]);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch(buildApiUrl(`/scans/${scanId}/reports`), {
        method: "POST",
        headers: { "X-Current-User-Id": "1" }
      });
      if (res.ok) {
        const data = (await res.json()) as AiReportResponse;
        setReportText(data.report_text);
        setGeneratedAt(data.generated_at);
        setModelName(data.model);
        setDownloadUrl(data.download_url);
        setSelectedReportId(data.report_id);
        void fetchHistory();
      }
    } catch {
      // toast error
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectHistory = async (reportId: number) => {
    try {
      const res = await fetch(buildApiUrl(`/scans/${scanId}/reports/${reportId}`), {
        headers: { "X-Current-User-Id": "1" }
      });
      if (res.ok) {
        const data = (await res.json()) as AiReportResponse;
        setReportText(data.report_text);
        setGeneratedAt(data.generated_at);
        setModelName(data.model);
        setDownloadUrl(data.download_url);
        setSelectedReportId(data.report_id);
      }
    } catch {
      // ignore
    }
  };

  const handleDownload = async () => {
    if (!selectedReportId) return;
    setIsDownloading(true);
    try {
      const report = history.find(h => h.id === selectedReportId) || { download_url: downloadUrl };
      const url = report.download_url;
      if (!url) throw new Error("No download URL");
      
      const response = await fetch(buildApiUrl(url), {
        headers: { "X-Current-User-Id": "1" }
      });
      if (!response.ok) throw new Error("Download failed");
      
      const blob = await response.blob();
      const downloadLink = document.createElement("a");
      downloadLink.href = URL.createObjectURL(blob);
      downloadLink.download = `scan_report_${scanId}_${selectedReportId}.pdf`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    } catch (err) {
      console.error("PDF download failed:", err);
    } finally {
      setIsDownloading(false);
    }
  };

  const isCompleted = scanStatus.toLowerCase() === "completed";

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm lg:p-8">
      {/* Header */}
      <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-6">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest text-indigo-600">AI Insights</p>
          <h3 className="mt-1 text-2xl font-bold text-slate-900">Security Analysis Report</h3>
        </div>

        <button
          id="generate-ai-report-btn"
          type="button"
          disabled={!isCompleted || isGenerating}
          onClick={() => void handleGenerate()}
          className="flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-6 py-3 text-sm font-bold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isGenerating ? (
            <>
              <Spinner />
              Generating...
            </>
          ) : (
            "Generate AI Report"
          )}
        </button>
      </div>

      {!isCompleted && !reportText ? (
        <div className="mt-8 rounded-xl bg-slate-50 p-6 text-center">
          <p className="text-sm text-slate-500 font-medium">
            Report generation will be available once the scan is completed.
          </p>
        </div>
      ) : null}

      {isGenerating ? (
        <div className="mt-8 flex flex-col items-center justify-center space-y-4 rounded-xl border-2 border-dashed border-slate-200 py-16">
          <div className="flex items-center gap-3 text-indigo-600">
            <Spinner />
          </div>
          <div className="text-center">
            <p className="text-sm font-bold text-slate-900">Analyzing scan data...</p>
            <p className="mt-1 text-xs text-slate-500">Synthesizing findings into a detailed report.</p>
          </div>
        </div>
      ) : null}

      {/* Report content */}
      <div className="mt-8 flex flex-col gap-8 lg:flex-row lg:items-start">
        {/* Main report viewer */}
        <div className="flex-1">
          {reportText ? (
            <div className="space-y-6">
              {/* Meta bar + Download */}
              <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl bg-slate-50 p-4">
                <div className="flex flex-wrap gap-6 text-xs font-medium text-slate-500">
                  {generatedAt ? (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] uppercase tracking-wider opacity-60">Generated At</span>
                      <span className="text-slate-900">{new Date(generatedAt).toLocaleString()}</span>
                    </div>
                  ) : null}
                  {modelName ? (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] uppercase tracking-wider opacity-60">Engine</span>
                      <span className="text-indigo-600">{modelName}</span>
                    </div>
                  ) : null}
                </div>

                {downloadUrl ? (
                  <button
                    id="download-ai-report-pdf-btn"
                    type="button"
                    disabled={isDownloading}
                    onClick={() => void handleDownload()}
                    className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-700 transition hover:bg-slate-50"
                  >
                    {isDownloading ? (
                      <Spinner />
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="h-4 w-4">
                        <path d="M10.75 2.75a.75.75 0 0 0-1.5 0v8.614L6.295 8.235a.75.75 0 1 0-1.09 1.03l4.25 4.5a.75.75 0 0 0 1.09 0l4.25-4.5a.75.75 0 0 0-1.09-1.03l-2.955 3.129V2.75Z" />
                        <path d="M3.5 12.75a.75.75 0 0 0-1.5 0v2.5A2.75 2.75 0 0 0 4.75 18h10.5A2.75 2.75 0 0 0 18 15.25v-2.5a.75.75 0 0 0-1.5 0v2.5c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25v-2.5Z" />
                      </svg>
                    )}
                    Export PDF
                  </button>
                ) : null}
              </div>

              <div className="prose prose-slate max-w-none rounded-xl border border-slate-100 bg-white p-8 lg:p-10">
                <RenderedReport text={reportText} />
              </div>
            </div>
          ) : null}
        </div>

        {/* History sidebar */}
        {history.length > 0 && (
          <div className="w-full shrink-0 lg:w-72">
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] text-slate-400">Report History</h4>
            <div className="mt-4 grid grid-cols-1 gap-2">
              {history.map((h) => (
                <button
                  key={h.id}
                  onClick={() => void handleSelectHistory(h.id)}
                  className={`flex flex-col rounded-xl border p-4 text-left transition-all ${
                    selectedReportId === h.id
                      ? "border-indigo-600 bg-indigo-50 ring-1 ring-indigo-600"
                      : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-400">#{h.id}</span>
                    <span className="text-[10px] font-bold text-indigo-600">{h.model}</span>
                  </div>
                  <span className="mt-2 text-xs font-bold text-slate-900">
                    {h.created_at ? new Date(h.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : "Unknown"}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
