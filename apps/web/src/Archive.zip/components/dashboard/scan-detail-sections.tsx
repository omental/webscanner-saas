"use client";

import { Scan } from "@/lib/types";
import { ScanStatusBadge } from "./scan-status-badge";
import { Badge } from "@/components/ui/badge";

/* ------------------------------------------------------------------ */
/*  Audit Dashboard (Scores)                                          */
/* ------------------------------------------------------------------ */

export function AuditDashboard({ scan }: { scan: Scan }) {
  const scores = [
    { label: "Critical", count: scan.critical_findings || 0, color: "text-rose-600", bg: "bg-rose-50" },
    { label: "High", count: scan.high_findings || 0, color: "text-orange-600", bg: "bg-orange-50" },
    { label: "Medium", count: scan.medium_findings || 0, color: "text-amber-600", bg: "bg-amber-50" },
    { label: "Low", count: scan.low_findings || 0, color: "text-indigo-600", bg: "bg-indigo-50" }
  ];

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {scores.map((score) => (
        <div key={score.label} className={`rounded-2xl border border-slate-200 bg-white p-6 shadow-sm`}>
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold uppercase tracking-wider text-slate-500">{score.label}</span>
            <div className={`rounded-lg ${score.bg} px-2.5 py-1 text-sm font-bold ${score.color}`}>
              {score.count}
            </div>
          </div>
          <div className="mt-4">
            <div className="h-2 w-full rounded-full bg-slate-100">
              <div
                className={`h-full rounded-full ${score.bg.replace("bg-", "bg-").replace("50", "500")}`}
                style={{ width: `${Math.min((score.count / 20) * 100, 100)}%` }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Findings List                                                     */
/* ------------------------------------------------------------------ */

export function FindingsList({ scan }: { scan: Scan }) {
  const findings = scan.findings || [];

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
      <div className="border-b border-slate-100 p-6">
        <h3 className="text-lg font-bold text-slate-900">Vulnerabilities Found</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/50 text-xs font-bold uppercase tracking-wider text-slate-400">
              <th className="px-6 py-4">Finding</th>
              <th className="px-6 py-4">Severity</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4">Path</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {findings.map((f, i) => (
              <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4 font-bold text-slate-900">{f.title}</td>
                <td className="px-6 py-4">
                  <Badge variant={f.severity.toLowerCase() as any}>{f.severity}</Badge>
                </td>
                <td className="px-6 py-4">
                   <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600">
                    <span className="h-1.5 w-1.5 rounded-full bg-indigo-500" />
                    Open
                  </span>
                </td>
                <td className="px-6 py-4 font-mono text-xs text-slate-500 truncate max-w-[200px]">
                  {f.path || "/"}
                </td>
              </tr>
            ))}
            {findings.length === 0 && (
              <tr>
                <td colSpan={4} className="px-6 py-12 text-center text-slate-400 italic">
                  No security issues detected.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Technology Grid                                                   */
/* ------------------------------------------------------------------ */

export function TechnologyGrid({ scan }: { scan: Scan }) {
  const techs = scan.technologies || [];

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-slate-900">Detected Stack</h3>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {techs.map((t, i) => (
          <div key={i} className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-all hover:border-indigo-200">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-50 text-indigo-600">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6">
                <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 6.75L22.5 12l-5.25 5.25m-10.5 0L1.5 12l5.25-5.25m7.5-3l-4.5 16.5" />
              </svg>
            </div>
            <div>
              <p className="text-sm font-bold text-slate-900">{t.name}</p>
              <p className="text-xs text-slate-500">{t.category || "Technology"}</p>
            </div>
          </div>
        ))}
        {techs.length === 0 && (
          <div className="col-span-full rounded-xl border border-dashed border-slate-200 py-10 text-center text-slate-400">
            No technologies identified.
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Pages List                                                        */
/* ------------------------------------------------------------------ */

export function PagesList({ scan }: { scan: Scan }) {
  const pages = scan.pages || [];

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm overflow-hidden">
      <div className="border-b border-slate-100 p-6">
        <h3 className="text-lg font-bold text-slate-900">Indexed Pages</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/50 text-xs font-bold uppercase tracking-wider text-slate-400">
              <th className="px-6 py-4">URL Path</th>
              <th className="px-6 py-4 text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {pages.map((p, i) => (
              <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4 font-mono text-xs text-slate-600">{p.url}</td>
                <td className="px-6 py-4 text-right">
                  <span className="inline-flex items-center rounded-md bg-emerald-50 px-2 py-1 text-xs font-bold text-emerald-700 ring-1 ring-inset ring-emerald-600/10">
                    200 OK
                  </span>
                </td>
              </tr>
            ))}
            {pages.length === 0 && (
              <tr>
                <td colSpan={2} className="px-6 py-12 text-center text-slate-400 italic">
                  No pages scanned yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
