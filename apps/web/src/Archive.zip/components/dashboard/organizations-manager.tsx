"use client";

import { FormEvent, useEffect, useState } from "react";

import { apiClient } from "@/lib/api-client";
import { Organization, Package } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";

function toDateTimeLocal(value: string | null) {
  return value ? value.slice(0, 16) : "";
}

function fromDateTimeLocal(value: string) {
  return value ? new Date(value).toISOString() : null;
}

export function OrganizationsManager() {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [packages, setPackages] = useState<Package[]>([]);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [packageId, setPackageId] = useState("");
  const [packageDrafts, setPackageDrafts] = useState<Record<number, string>>({});
  const [subscriptionDrafts, setSubscriptionDrafts] = useState<
    Record<
      number,
      {
        subscription_status: string;
        subscription_start: string;
        subscription_end: string;
        trial_ends_at: string;
      }
    >
  >({});
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadData() {
    try {
      setLoading(true);
      setError(null);
      const [nextOrganizations, nextPackages] = await Promise.all([
        apiClient.listOrganizations(),
        apiClient.listPackages()
      ]);
      setOrganizations(nextOrganizations);
      setSubscriptionDrafts(
        Object.fromEntries(
          nextOrganizations.map((organization) => [
            organization.id,
            {
              subscription_status: organization.subscription_status,
              subscription_start: toDateTimeLocal(organization.subscription_start),
              subscription_end: toDateTimeLocal(organization.subscription_end),
              trial_ends_at: toDateTimeLocal(organization.trial_ends_at)
            }
          ])
        )
      );
      setPackageDrafts(
        Object.fromEntries(
          nextOrganizations.map((organization) => [
            organization.id,
            organization.package_id?.toString() ?? ""
          ])
        )
      );
      setPackages(nextPackages);
    } catch {
      setError("Unable to load organizations.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadData();
  }, []);

  async function handleCreate(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      setSubmitting(true);
      setError(null);
      await apiClient.createOrganization({
        name,
        slug,
        package_id: packageId ? Number(packageId) : null,
        status: "active"
      });
      setName("");
      setSlug("");
      setPackageId("");
      await loadData();
    } catch {
      setError("Unable to create organization.");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleAssignPackage(organizationId: number) {
    const nextPackageId = packageDrafts[organizationId] ?? "";
    try {
      setError(null);
      await apiClient.assignOrganizationPackage(
        organizationId,
        nextPackageId ? Number(nextPackageId) : null
      );
      await loadData();
    } catch {
      setError("Unable to assign package.");
    }
  }

  function updateSubscriptionDraft(
    organizationId: number,
    field:
      | "subscription_status"
      | "subscription_start"
      | "subscription_end"
      | "trial_ends_at",
    value: string
  ) {
    setSubscriptionDrafts((current) => ({
      ...current,
      [organizationId]: {
        ...current[organizationId],
        [field]: value
      }
    }));
  }

  async function handleSaveSubscription(organizationId: number) {
    const draft = subscriptionDrafts[organizationId];
    if (!draft) {
      return;
    }
    try {
      setError(null);
      await apiClient.updateOrganizationSubscription(organizationId, {
        subscription_status: draft.subscription_status,
        subscription_start: fromDateTimeLocal(draft.subscription_start),
        subscription_end: fromDateTimeLocal(draft.subscription_end),
        trial_ends_at: fromDateTimeLocal(draft.trial_ends_at)
      });
      await loadData();
    } catch {
      setError("Unable to save subscription.");
    }
  }

  async function handleStartTrial(organizationId: number) {
    try {
      setError(null);
      await apiClient.startOrganizationTrial(organizationId, 14);
      await loadData();
    } catch {
      setError("Unable to start trial.");
    }
  }

  return (
    <section className="space-y-6">
      <form
        className="rounded-[1.75rem] border border-white/10 bg-slate-950/70 p-6"
        onSubmit={handleCreate}
      >
        <div className="grid gap-4 md:grid-cols-[1fr_1fr_1fr_auto]">
          <Input
            label="Organization name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            required
          />
          <Input
            label="Slug"
            value={slug}
            onChange={(event) => setSlug(event.target.value)}
            required
          />
          <Select
            label="Package"
            value={packageId}
            onChange={(event) => setPackageId(event.target.value)}
          >
            <option value="">No package</option>
            {packages.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </Select>
          <div className="flex items-end">
            <Button type="submit" disabled={submitting} fullWidth>
              {submitting ? "Creating..." : "Create"}
            </Button>
          </div>
        </div>
        {error ? <p className="mt-4 text-sm text-rose-300">{error}</p> : null}
      </form>

      <div className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6">
        <div className="flex items-center justify-between gap-4">
          <p className="text-sm font-medium text-white">Organizations</p>
          <Button variant="secondary" onClick={() => void loadData()}>
            Refresh
          </Button>
        </div>
        {loading ? (
          <p className="mt-4 text-sm text-slate-400">Loading organizations...</p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="min-w-full divide-y divide-white/10 text-left text-sm">
              <thead className="text-xs uppercase tracking-[0.2em] text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-medium">Name</th>
                  <th className="px-4 py-3 font-medium">Slug</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Package</th>
                  <th className="px-4 py-3 font-medium">Subscription</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10 text-slate-200">
                {organizations.map((organization) => (
                  <tr key={organization.id}>
                    <td className="px-4 py-4 font-medium text-white">
                      {organization.name}
                    </td>
                    <td className="px-4 py-4 text-slate-300">{organization.slug}</td>
                    <td className="px-4 py-4 text-slate-300">{organization.status}</td>
                    <td className="px-4 py-4">
                      <Select
                        label="Package"
                        value={
                          packageDrafts[organization.id] ??
                          organization.package_id?.toString() ??
                          ""
                        }
                        onChange={(event) =>
                          setPackageDrafts((current) => ({
                            ...current,
                            [organization.id]: event.target.value
                          }))
                        }
                      >
                        <option value="">No package</option>
                        {packages.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.name}
                          </option>
                        ))}
                      </Select>
                      <Button
                        className="mt-3 px-3 py-2"
                        onClick={() => void handleAssignPackage(organization.id)}
                      >
                        Save package
                      </Button>
                    </td>
                    <td className="min-w-[24rem] px-4 py-4">
                      <div className="grid gap-3">
                        <Select
                          label="Subscription status"
                          value={
                            subscriptionDrafts[organization.id]
                              ?.subscription_status ?? organization.subscription_status
                          }
                          onChange={(event) =>
                            updateSubscriptionDraft(
                              organization.id,
                              "subscription_status",
                              event.target.value
                            )
                          }
                        >
                          <option value="active">Active</option>
                          <option value="trial">Trial</option>
                          <option value="expired">Expired</option>
                          <option value="suspended">Suspended</option>
                        </Select>
                        <div className="grid gap-3 md:grid-cols-3">
                          <Input
                            label="Start"
                            type="datetime-local"
                            value={
                              subscriptionDrafts[organization.id]
                                ?.subscription_start ?? ""
                            }
                            onChange={(event) =>
                              updateSubscriptionDraft(
                                organization.id,
                                "subscription_start",
                                event.target.value
                              )
                            }
                          />
                          <Input
                            label="End"
                            type="datetime-local"
                            value={
                              subscriptionDrafts[organization.id]
                                ?.subscription_end ?? ""
                            }
                            onChange={(event) =>
                              updateSubscriptionDraft(
                                organization.id,
                                "subscription_end",
                                event.target.value
                              )
                            }
                          />
                          <Input
                            label="Trial ends"
                            type="datetime-local"
                            value={
                              subscriptionDrafts[organization.id]?.trial_ends_at ?? ""
                            }
                            onChange={(event) =>
                              updateSubscriptionDraft(
                                organization.id,
                                "trial_ends_at",
                                event.target.value
                              )
                            }
                          />
                        </div>
                        <div className="flex flex-wrap gap-2">
                          <Button
                            className="px-3 py-2"
                            onClick={() => void handleSaveSubscription(organization.id)}
                          >
                            Save subscription
                          </Button>
                          <Button
                            variant="secondary"
                            className="px-3 py-2"
                            onClick={() => void handleStartTrial(organization.id)}
                          >
                            Start 14-day trial
                          </Button>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}
