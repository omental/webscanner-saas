"use client";

import { FormEvent, useEffect, useState } from "react";

import { apiClient } from "@/lib/api-client";
import { PaymentMethod } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Draft = {
  description: string;
  displayName: string;
  mode: "test" | "live";
  publicKey: string;
  secretKey: string;
  webhookSecret: string;
  webhookEnabled: boolean;
  bankName: string;
  accountName: string;
  accountNumber: string;
  iban: string;
  swift: string;
  routingNumber: string;
  instructions: string;
};

const gatewaySlugs = new Set(["stripe", "paypal"]);

function readConfigValue(
  config: Record<string, unknown> | null,
  key: string
): string {
  const value = config?.[key];
  return typeof value === "string" ? value : "";
}

export function PaymentMethodsManager() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [drafts, setDrafts] = useState<Record<number, Draft>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function loadPaymentMethods() {
    try {
      setLoading(true);
      setError(null);
      const data = await apiClient.listPaymentMethods();
      setPaymentMethods(data);
      setDrafts(
        Object.fromEntries(
          data.map((method) => [
            method.id,
            {
              description: method.description ?? "",
              displayName:
                typeof method.config_json?.display_name === "string"
                  ? method.config_json.display_name
                  : "",
              mode: method.mode,
              publicKey: method.public_key ?? "",
              secretKey: "",
              webhookSecret: "",
              webhookEnabled: method.webhook_enabled,
              bankName: readConfigValue(method.config_json, "bank_name"),
              accountName: readConfigValue(method.config_json, "account_name"),
              accountNumber: readConfigValue(method.config_json, "account_number"),
              iban: readConfigValue(method.config_json, "iban"),
              swift: readConfigValue(method.config_json, "swift"),
              routingNumber: readConfigValue(method.config_json, "routing_number"),
              instructions: readConfigValue(method.config_json, "instructions")
            }
          ])
        )
      );
    } catch {
      setError("Unable to load payment methods.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadPaymentMethods();
  }, []);

  function updateDraft(
    id: number,
    field: keyof Draft,
    value: string | boolean
  ) {
    setDrafts((current) => ({
      ...current,
      [id]: {
        ...current[id],
        [field]: value
      }
    }));
  }

  async function toggleActive(method: PaymentMethod) {
    await apiClient.updatePaymentMethod(method.id, {
      is_active: !method.is_active
    });
    await loadPaymentMethods();
  }

  async function saveMethod(event: FormEvent<HTMLFormElement>, method: PaymentMethod) {
    event.preventDefault();
    const draft = drafts[method.id] ?? emptyDraft(method);
    const isGateway = gatewaySlugs.has(method.slug);
    const config_json =
      method.slug === "bank_transfer"
        ? {
            bank_name: draft.bankName || null,
            account_name: draft.accountName || null,
            account_number: draft.accountNumber || null,
            iban: draft.iban || null,
            swift: draft.swift || null,
            routing_number: draft.routingNumber || null,
            instructions: draft.instructions || null
          }
        : draft.displayName
          ? { display_name: draft.displayName }
          : null;
    await apiClient.updatePaymentMethod(method.id, {
      description: draft.description || null,
      config_json,
      ...(isGateway
        ? {
            mode: draft.mode,
            public_key: draft.publicKey || null,
            secret_key: draft.secretKey || null,
            webhook_secret: draft.webhookSecret || null,
            webhook_enabled: draft.webhookEnabled
          }
        : {})
    });
    await loadPaymentMethods();
  }

  async function clearSecret(method: PaymentMethod, field: "secret" | "webhook") {
    await apiClient.updatePaymentMethod(method.id, {
      [field === "secret" ? "clear_secret_key" : "clear_webhook_secret"]: true
    });
    await loadPaymentMethods();
  }

  function emptyDraft(method: PaymentMethod): Draft {
    return {
      description: method.description ?? "",
      displayName: readConfigValue(method.config_json, "display_name"),
      mode: method.mode,
      publicKey: method.public_key ?? "",
      secretKey: "",
      webhookSecret: "",
      webhookEnabled: method.webhook_enabled,
      bankName: readConfigValue(method.config_json, "bank_name"),
      accountName: readConfigValue(method.config_json, "account_name"),
      accountNumber: readConfigValue(method.config_json, "account_number"),
      iban: readConfigValue(method.config_json, "iban"),
      swift: readConfigValue(method.config_json, "swift"),
      routingNumber: readConfigValue(method.config_json, "routing_number"),
      instructions: readConfigValue(method.config_json, "instructions")
    };
  }

  return (
    <section className="space-y-4">
      <div className="flex justify-end">
        <Button variant="secondary" onClick={() => void loadPaymentMethods()}>
          Refresh
        </Button>
      </div>
      {loading ? (
        <p className="text-sm text-slate-400">Loading payment methods...</p>
      ) : error ? (
        <p className="text-sm text-rose-300">{error}</p>
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          {paymentMethods.map((method) => {
            const draft = drafts[method.id] ?? {
              description: "",
              displayName: "",
              mode: method.mode,
              publicKey: "",
              secretKey: "",
              webhookSecret: "",
              webhookEnabled: method.webhook_enabled,
              bankName: "",
              accountName: "",
              accountNumber: "",
              iban: "",
              swift: "",
              routingNumber: "",
              instructions: ""
            };
            const isGateway = gatewaySlugs.has(method.slug);
            const publicLabel =
              method.slug === "paypal" ? "Client ID" : "Publishable key";
            const secretLabel =
              method.slug === "paypal" ? "Client secret" : "Secret key";
            const webhookSecretLabel =
              method.slug === "paypal"
                ? "Webhook ID / secret"
                : "Webhook signing secret";
            return (
              <form
                key={method.id}
                className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6"
                onSubmit={(event) => void saveMethod(event, method)}
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-lg font-semibold text-white">
                      {method.name}
                    </p>
                    <p className="mt-1 text-sm text-slate-400">{method.slug}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void toggleActive(method)}
                    className={`rounded-full px-3 py-1 text-xs font-semibold ${
                      method.is_active
                        ? "bg-emerald-400/15 text-emerald-200"
                        : "bg-slate-700 text-slate-200"
                    }`}
                  >
                    {method.is_active ? "Active" : "Inactive"}
                  </button>
                </div>
                <div className="mt-5 space-y-4">
                  <Input
                    label="Description"
                    value={draft.description}
                    onChange={(event) =>
                      updateDraft(method.id, "description", event.target.value)
                    }
                  />
                  <Input
                    label="Display name"
                    value={draft.displayName}
                    onChange={(event) =>
                      updateDraft(method.id, "displayName", event.target.value)
                    }
                  />
                  {isGateway ? (
                    <>
                      <label className="block">
                        <span className="mb-2 block text-sm text-slate-300">
                          Mode
                        </span>
                        <select
                          value={draft.mode}
                          onChange={(event) =>
                            updateDraft(
                              method.id,
                              "mode",
                              event.target.value as "test" | "live"
                            )
                          }
                          className="w-full rounded-2xl border border-white/10 bg-slate-950/80 px-4 py-3 text-sm text-white outline-none transition focus:border-cyan-400"
                        >
                          <option value="test">Test</option>
                          <option value="live">Live</option>
                        </select>
                      </label>
                      <Input
                        label={publicLabel}
                        value={draft.publicKey}
                        onChange={(event) =>
                          updateDraft(method.id, "publicKey", event.target.value)
                        }
                      />
                      <div className="space-y-2">
                        <Input
                          label={secretLabel}
                          type="password"
                          value={draft.secretKey}
                          placeholder="Leave blank to keep existing secret"
                          onChange={(event) =>
                            updateDraft(method.id, "secretKey", event.target.value)
                          }
                        />
                        <div className="flex items-center justify-between gap-3">
                          {method.has_secret_key ? (
                            <span className="rounded-full bg-emerald-400/15 px-3 py-1 text-xs font-semibold text-emerald-200">
                              Secret saved
                            </span>
                          ) : (
                            <span className="text-xs text-slate-500">
                              No secret saved
                            </span>
                          )}
                          <Button
                            variant="ghost"
                            className="px-3 py-2"
                            onClick={() => void clearSecret(method, "secret")}
                          >
                            Clear secret
                          </Button>
                        </div>
                      </div>
                      <Input
                        label="Webhook URL"
                        value={
                          method.webhook_url ??
                          `/api/v1/webhooks/${method.slug}`
                        }
                        readOnly
                      />
                      <label className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-slate-950/50 px-4 py-3 text-sm text-slate-200">
                        <span>Webhook enabled</span>
                        <input
                          type="checkbox"
                          checked={draft.webhookEnabled}
                          onChange={(event) =>
                            updateDraft(
                              method.id,
                              "webhookEnabled",
                              event.target.checked
                            )
                          }
                          className="h-4 w-4 accent-cyan-400"
                        />
                      </label>
                      <div className="space-y-2">
                        <Input
                          label={webhookSecretLabel}
                          type="password"
                          value={draft.webhookSecret}
                          placeholder="Leave blank to keep existing secret"
                          onChange={(event) =>
                            updateDraft(
                              method.id,
                              "webhookSecret",
                              event.target.value
                            )
                          }
                        />
                        <div className="flex items-center justify-between gap-3">
                          {method.has_webhook_secret ? (
                            <span className="rounded-full bg-emerald-400/15 px-3 py-1 text-xs font-semibold text-emerald-200">
                              Webhook secret saved
                            </span>
                          ) : (
                            <span className="text-xs text-slate-500">
                              No webhook secret saved
                            </span>
                          )}
                          <Button
                            variant="ghost"
                            className="px-3 py-2"
                            onClick={() => void clearSecret(method, "webhook")}
                          >
                            Clear webhook secret
                          </Button>
                        </div>
                      </div>
                    </>
                  ) : null}
                  {method.slug === "bank_transfer" ? (
                    <>
                      <Input
                        label="Bank name"
                        value={draft.bankName}
                        onChange={(event) =>
                          updateDraft(method.id, "bankName", event.target.value)
                        }
                      />
                      <Input
                        label="Account name"
                        value={draft.accountName}
                        onChange={(event) =>
                          updateDraft(method.id, "accountName", event.target.value)
                        }
                      />
                      <Input
                        label="Account number"
                        value={draft.accountNumber}
                        onChange={(event) =>
                          updateDraft(method.id, "accountNumber", event.target.value)
                        }
                      />
                      <Input
                        label="IBAN"
                        value={draft.iban}
                        onChange={(event) =>
                          updateDraft(method.id, "iban", event.target.value)
                        }
                      />
                      <Input
                        label="SWIFT"
                        value={draft.swift}
                        onChange={(event) =>
                          updateDraft(method.id, "swift", event.target.value)
                        }
                      />
                      <Input
                        label="Routing number"
                        value={draft.routingNumber}
                        onChange={(event) =>
                          updateDraft(method.id, "routingNumber", event.target.value)
                        }
                      />
                      <Input
                        label="Instructions"
                        value={draft.instructions}
                        onChange={(event) =>
                          updateDraft(method.id, "instructions", event.target.value)
                        }
                      />
                    </>
                  ) : null}
                </div>
                <Button type="submit" className="mt-5">
                  Save settings
                </Button>
              </form>
            );
          })}
        </div>
      )}
    </section>
  );
}
