"use client";

import { useCallback, useEffect, useState } from "react";

import { InvoicesManager } from "@/components/dashboard/invoices-manager";
import { Button } from "@/components/ui/button";
import { Select } from "@/components/ui/select";
import { apiClient } from "@/lib/api-client";
import { Organization } from "@/lib/types";

export function AdminBillingManager() {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [organizationId, setOrganizationId] = useState("");
  const [generating, setGenerating] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const loadOrganizations = useCallback(async () => {
    const data = await apiClient.listOrganizations();
    setOrganizations(data);
    if (!organizationId && data[0]) {
      setOrganizationId(String(data[0].id));
    }
  }, [organizationId]);

  useEffect(() => {
    void loadOrganizations();
  }, [loadOrganizations]);

  async function generateInvoice() {
    if (!organizationId) {
      return;
    }
    try {
      setGenerating(true);
      setMessage(null);
      const invoice = await apiClient.generateBillingInvoice(Number(organizationId));
      setMessage(`Generated ${invoice.invoice_number}.`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to generate invoice.");
    } finally {
      setGenerating(false);
    }
  }

  return (
    <section className="space-y-6">
      <div className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6">
        <div className="grid gap-4 md:grid-cols-[1fr_auto] md:items-end">
          <Select
            label="Organization"
            value={organizationId}
            onChange={(event) => setOrganizationId(event.target.value)}
          >
            {organizations.map((organization) => (
              <option key={organization.id} value={organization.id}>
                {organization.name}
              </option>
            ))}
          </Select>
          <Button onClick={() => void generateInvoice()} disabled={generating}>
            {generating ? "Generating..." : "Generate invoice"}
          </Button>
        </div>
        {message ? <p className="mt-4 text-sm text-slate-300">{message}</p> : null}
      </div>
      <InvoicesManager superAdmin />
    </section>
  );
}
