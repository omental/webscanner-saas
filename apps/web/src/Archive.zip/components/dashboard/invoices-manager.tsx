"use client";

import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { apiClient, buildApiUrl } from "@/lib/api-client";
import { Invoice } from "@/lib/types";

type InvoicesManagerProps = {
  superAdmin?: boolean;
};

function formatDate(value: string) {
  return new Date(value).toLocaleDateString();
}

export function InvoicesManager({ superAdmin = false }: InvoicesManagerProps) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function loadInvoices() {
    try {
      setLoading(true);
      setError(null);
      setInvoices(await apiClient.listInvoices());
    } catch (invoiceError) {
      setError(
        invoiceError instanceof Error
          ? invoiceError.message
          : "Unable to load invoices."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadInvoices();
  }, []);

  async function markPaid(invoice: Invoice) {
    await apiClient.markInvoicePaid(invoice.id);
    await loadInvoices();
  }

  if (loading) {
    return (
      <div className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6 text-sm text-slate-400">
        Loading invoices...
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-[1.75rem] border border-rose-400/20 bg-rose-400/10 p-6 text-sm text-rose-100">
        {error}
      </div>
    );
  }

  return (
    <section className="space-y-4">
      <div className="flex justify-end">
        <Button variant="secondary" onClick={() => void loadInvoices()}>
          Refresh
        </Button>
      </div>
      <div className="overflow-hidden rounded-[1.75rem] border border-white/10 bg-slate-950/70">
        <div className="grid gap-3 border-b border-white/10 px-5 py-3 text-xs uppercase tracking-[0.2em] text-slate-400 md:grid-cols-[1fr_1fr_1fr_0.8fr_0.8fr_auto]">
          <span>Invoice</span>
          <span>Organization</span>
          <span>Package</span>
          <span>Amount</span>
          <span>Status</span>
          <span>Actions</span>
        </div>
        {invoices.length === 0 ? (
          <p className="p-5 text-sm text-slate-400">No invoices yet.</p>
        ) : (
          invoices.map((invoice) => (
            <div
              key={invoice.id}
              className="grid gap-3 border-b border-white/10 px-5 py-4 text-sm text-slate-200 last:border-b-0 md:grid-cols-[1fr_1fr_1fr_0.8fr_0.8fr_auto] md:items-center"
            >
              <div>
                <p className="font-medium text-white">{invoice.invoice_number}</p>
                <p className="mt-1 text-xs text-slate-400">
                  Due {formatDate(invoice.due_date)}
                </p>
              </div>
              <span>{invoice.organization_name ?? `#${invoice.organization_id}`}</span>
              <span>{invoice.package_name ?? "Package"}</span>
              <span>
                {invoice.currency} {invoice.amount}
              </span>
              <span className="capitalize">{invoice.status}</span>
              <div className="flex flex-wrap gap-2">
                {invoice.pdf_url ? (
                  <a
                    href={buildApiUrl(invoice.pdf_url)}
                    target="_blank"
                    className="rounded-full border border-white/10 px-3 py-2 text-xs font-semibold text-cyan-300 hover:bg-white/5"
                  >
                    Download
                  </a>
                ) : null}
                {superAdmin && invoice.status !== "paid" ? (
                  <Button
                    variant="ghost"
                    className="px-3 py-2 text-xs"
                    onClick={() => void markPaid(invoice)}
                  >
                    Mark paid
                  </Button>
                ) : null}
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}
