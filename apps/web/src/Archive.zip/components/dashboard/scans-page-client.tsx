"use client";

import Link from "next/link";
import { FormEvent, useEffect, useRef, useState } from "react";

import { apiClient } from "@/lib/api-client";
import { Scan, Target, Usage } from "@/lib/types";
import { getSessionUser, SessionUser } from "@/lib/session";
import { ScanProgressPanel } from "@/components/dashboard/scan-progress-panel";
import { ScanStatusBadge } from "@/components/dashboard/scan-status-badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useToast } from "@/components/ui/toast-provider";

type ScansPageClientProps = {
  initialScans: Scan[];
  initialTargets: Target[];
  initialError?: string | null;
};

const activeStatuses = new Set(["queued", "pending", "running"]);
const stoppableStatuses = new Set(["queued", "running"]);
const notifiedStorageKey = "webscanner.scan-notifications";

function targetLabel(targets: Target[], targetId: number) {
  const target = targets.find((item) => item.id === targetId);
  return target?.normalized_domain ?? `Target #${targetId}`;
}

function formatDate(value: string) {
  return new Date(value).toLocaleString();
}

function hasActiveScans(scans: Scan[]) {
  return scans.some((scan) => activeStatuses.has(scan.status.toLowerCase()));
}

function readNotifiedScanEvents() {
  if (typeof window === "undefined") {
    return new Set<string>();
  }

  const value = window.localStorage.getItem(notifiedStorageKey);
  if (!value) {
    return new Set<string>();
  }

  try {
    return new Set<string>((JSON.parse(value) as unknown[]).map(String));
  } catch {
    return new Set<string>();
  }
}

function writeNotifiedScanEvents(scanEvents: Set<string>) {
  window.localStorage.setItem(notifiedStorageKey, JSON.stringify([...scanEvents]));
}

function notificationKey(scanId: number, event: string) {
  return `${scanId}:${event}`;
}

function replaceScan(scans: Scan[], nextScan: Scan) {
  return scans.map((scan) => (scan.id === nextScan.id ? nextScan : scan));
}

export function ScansPageClient({
  initialScans,
  initialTargets,
  initialError = null
}: ScansPageClientProps) {
  const { showToast } = useToast();
  const [sessionUser, setSessionUser] = useState<SessionUser | null>(null);
  const [scans, setScans] = useState<Scan[]>(initialScans);
  const [targets, setTargets] = useState<Target[]>(initialTargets);
  const [targetId, setTargetId] = useState(
    initialTargets[0] ? String(initialTargets[0].id) : ""
  );
  const [scanType, setScanType] = useState("full");
  const [maxPages, setMaxPages] = useState("");
  const [maxDepth, setMaxDepth] = useState("");
  const [timeoutSeconds, setTimeoutSeconds] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [cancellingScanIds, setCancellingScanIds] = useState<Set<number>>(new Set());
  const [error, setError] = useState<string | null>(initialError);
  const [usage, setUsage] = useState<Usage | null>(null);
  const [pollingEnabled, setPollingEnabled] = useState(hasActiveScans(initialScans));
  const previousScansRef = useRef<Scan[]>(initialScans);
  const notifiedScanEventsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    setSessionUser(getSessionUser());
    notifiedScanEventsRef.current = readNotifiedScanEvents();
    void refresh();
  }, []);

  async function refreshUsage() {
    const user = getSessionUser();
    if (user?.role !== "admin") {
      return;
    }
    try {
      setUsage(await apiClient.getMyUsage());
    } catch {
      setUsage(null);
    }
  }

  useEffect(() => {
    void refreshUsage();
  }, []);

  useEffect(() => {
    if (!targetId && targets[0]) {
      setTargetId(String(targets[0].id));
    }
  }, [targetId, targets]);

  function notifyStatusChanges(nextScans: Scan[]) {
    const notifiedEvents = notifiedScanEventsRef.current;

    for (const scan of nextScans) {
      const previousScan = previousScansRef.current.find((item) => item.id === scan.id);
      const previousStatus = previousScan?.status.toLowerCase();
      const status = scan.status.toLowerCase();

      if (
        previousScan &&
        previousStatus !== status &&
        status === "cancelled" &&
        !notifiedEvents.has(notificationKey(scan.id, "cancelled"))
      ) {
        showToast("Scan cancelled", "info");
        notifiedEvents.add(notificationKey(scan.id, "cancelled"));
      }

      if (
        previousScan &&
        previousStatus !== status &&
        status === "running" &&
        !notifiedEvents.has(notificationKey(scan.id, "started"))
      ) {
        showToast(`Scan #${scan.id} started.`, "info");
        notifiedEvents.add(notificationKey(scan.id, "started"));
      }

      if (
        previousScan &&
        previousStatus !== status &&
        status === "completed" &&
        !notifiedEvents.has(notificationKey(scan.id, "completed"))
      ) {
        showToast(`Scan #${scan.id} completed.`, "success");
        notifiedEvents.add(notificationKey(scan.id, "completed"));
      }

      if (
        previousScan &&
        previousStatus !== status &&
        status === "failed" &&
        !notifiedEvents.has(notificationKey(scan.id, "failed"))
      ) {
        showToast(`Scan #${scan.id} failed.`, "error");
        notifiedEvents.add(notificationKey(scan.id, "failed"));
      }
    }

    writeNotifiedScanEvents(notifiedEvents);
    previousScansRef.current = nextScans;
  }

  async function refresh(showRefreshState = true) {
    try {
      if (showRefreshState) {
        setLoading(true);
      }

      setError(null);
      const [nextScans, nextTargets] = await Promise.all([
        apiClient.listScans(),
        apiClient.listTargets()
      ]);

      notifyStatusChanges(nextScans);
      setScans(nextScans);
      setTargets(nextTargets);
      setPollingEnabled(hasActiveScans(nextScans));
      await refreshUsage();
    } catch {
      setError("Unable to load scans or targets right now.");
    } finally {
      if (showRefreshState) {
        setLoading(false);
      }
    }
  }

  async function handleCancelScan(scanId: number) {
    try {
      setError(null);
      setCancellingScanIds((current) => new Set(current).add(scanId));
      const cancelledScan = await apiClient.cancelScan(scanId);
      const notifiedEvents = notifiedScanEventsRef.current;
      notifiedEvents.add(notificationKey(scanId, "cancelled"));
      writeNotifiedScanEvents(notifiedEvents);
      setScans((current) => {
        const nextScans = replaceScan(current, cancelledScan);
        setPollingEnabled(hasActiveScans(nextScans));
        previousScansRef.current = nextScans;
        return nextScans;
      });
      showToast("Scan cancelled", "info");
    } catch (cancelError) {
      setError(
        cancelError instanceof Error ? cancelError.message : "Unable to cancel scan."
      );
    } finally {
      setCancellingScanIds((current) => {
        const next = new Set(current);
        next.delete(scanId);
        return next;
      });
    }
  }

  useEffect(() => {
    if (!pollingEnabled) {
      return undefined;
    }

    const interval = window.setInterval(() => {
      void refresh(false);
    }, 3000);

    return () => window.clearInterval(interval);
  }, [pollingEnabled]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      setSubmitting(true);
      setError(null);
      const scanLimits = {
        ...(maxPages ? { max_pages: Number(maxPages) } : {}),
        ...(maxDepth ? { max_depth: Number(maxDepth) } : {}),
        ...(timeoutSeconds ? { timeout_seconds: Number(timeoutSeconds) } : {})
      };
      const createdScan = await apiClient.createScan({
        user_id: sessionUser?.id ?? 1,
        target_id: Number(targetId),
        scan_type: scanType,
        ...scanLimits
      });
      showToast(`Scan #${createdScan.id} created.`, "success");
      await refresh(false);
      await refreshUsage();
      setPollingEnabled(true);
    } catch (submitError) {
      const message =
        submitError instanceof Error ? submitError.message : "Unable to create scan.";
      setError(message);
      showToast(message, "error");
    } finally {
      setSubmitting(false);
    }
  }

  const limitReached =
    sessionUser?.role === "admin" &&
    usage !== null &&
    usage.scans_remaining_this_week <= 0;

  return (
    <section className="space-y-6">
      {sessionUser?.role === "admin" ? (
      <div className="rounded-[1.75rem] border border-white/10 bg-slate-950/70 p-6">
        {targets.length === 0 && !error ? (
          <div className="mb-5 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-sm text-slate-300">
            No targets yet. Add a target before running a scan.
          </div>
        ) : null}
        {usage ? (
          <div className="mb-5 rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="text-sm font-medium text-white">
              {usage.package_name ?? "No package"} package
            </p>
            <p className="mt-2 text-sm text-slate-300">
              Scans used this week: {usage.scans_used_this_week} /{" "}
              {usage.scan_limit_per_week}
            </p>
            <p className="mt-1 text-sm text-slate-300">
              Remaining: {usage.scans_remaining_this_week}
            </p>
          </div>
        ) : null}
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="grid gap-4 md:grid-cols-[1fr_1fr_auto]">
            <Select
              label="Target"
              value={targetId}
              onChange={(event) => setTargetId(event.target.value)}
              disabled={targets.length === 0 || submitting}
            >
              {targets.length === 0 ? (
                <option value="">No targets available</option>
              ) : null}
              {targets.map((target) => (
                <option key={target.id} value={target.id}>
                  {target.normalized_domain}
                </option>
              ))}
            </Select>

            <Select
              label="Scan type"
              value={scanType}
              onChange={(event) => setScanType(event.target.value)}
              disabled={submitting}
            >
              <option value="full">Full</option>
              <option value="quick">Quick</option>
            </Select>

            <div className="flex items-end">
              <Button
                type="submit"
                disabled={!targetId || submitting || limitReached}
                fullWidth
              >
                {limitReached
                  ? "Weekly limit reached"
                  : submitting
                    ? "Creating..."
                    : "Create scan"}
              </Button>
            </div>
          </div>

          <details className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <summary className="cursor-pointer list-none text-sm font-medium text-slate-200">
              Advanced Options
            </summary>
            <div className="mt-4 grid gap-4 md:grid-cols-3">
              <Input
                label="Max pages"
                type="number"
                min={1}
                max={1000}
                placeholder="Use default"
                value={maxPages}
                onChange={(event) => setMaxPages(event.target.value)}
                disabled={submitting}
              />
              <Input
                label="Max depth"
                type="number"
                min={0}
                max={10}
                placeholder="Use default"
                value={maxDepth}
                onChange={(event) => setMaxDepth(event.target.value)}
                disabled={submitting}
              />
              <Input
                label="Timeout seconds"
                type="number"
                min={3}
                max={60}
                placeholder="Use default"
                value={timeoutSeconds}
                onChange={(event) => setTimeoutSeconds(event.target.value)}
                disabled={submitting}
              />
            </div>
          </details>
        </form>
        {error ? <p className="mt-4 text-sm text-rose-300">{error}</p> : null}
      </div>
      ) : null}

      {scans.some((scan) => activeStatuses.has(scan.status.toLowerCase())) ? (
        <div className="space-y-3">
          {scans
            .filter((scan) => activeStatuses.has(scan.status.toLowerCase()))
            .map((scan) => (
              <ScanProgressPanel
                key={scan.id}
                scan={scan}
                targetLabel={targetLabel(targets, scan.target_id)}
                compact
              />
            ))}
        </div>
      ) : null}

      <div className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-white">Scan runs</p>
            {pollingEnabled ? (
              <p className="mt-1 text-xs text-cyan-300">
                Live updates enabled while scans are active.
              </p>
            ) : null}
          </div>
          <Button variant="secondary" onClick={() => void refresh()}>
            {loading ? "Refreshing..." : "Refresh"}
          </Button>
        </div>

        {loading && scans.length === 0 ? (
          <p className="mt-4 text-sm text-slate-400">Loading scans...</p>
        ) : error && scans.length === 0 ? (
          <p className="mt-4 text-sm text-rose-300">{error}</p>
        ) : scans.length === 0 ? (
          <p className="mt-4 text-sm text-slate-400">
            No scans yet.
          </p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="min-w-full divide-y divide-white/10 text-left">
              <thead className="text-xs uppercase tracking-[0.2em] text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-medium">Scan</th>
                  <th className="px-4 py-3 font-medium">Target</th>
                  <th className="px-4 py-3 font-medium">Type</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Pages</th>
                  <th className="px-4 py-3 font-medium">Findings</th>
                  <th className="px-4 py-3 font-medium">Created</th>
                  <th className="px-4 py-3 font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10 text-sm text-slate-200">
                {scans.map((scan) => (
                  <tr key={scan.id}>
                    <td className="px-4 py-4 font-medium text-white">
                      #{scan.id}
                    </td>
                    <td className="px-4 py-4 text-slate-300">
                      {targetLabel(targets, scan.target_id)}
                    </td>
                    <td className="px-4 py-4">{scan.scan_type}</td>
                    <td className="px-4 py-4">
                      <ScanStatusBadge status={scan.status} />
                    </td>
                    <td className="px-4 py-4">{scan.total_pages_found}</td>
                    <td className="px-4 py-4">{scan.total_findings}</td>
                    <td className="px-4 py-4 text-slate-300">
                      {formatDate(scan.created_at)}
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex flex-wrap items-center gap-3">
                        <Link
                          href={`/dashboard/scans/${scan.id}`}
                          className="text-cyan-300 transition hover:text-cyan-200"
                        >
                          View details
                        </Link>
                        {sessionUser?.role === "admin" &&
                        stoppableStatuses.has(scan.status.toLowerCase()) ? (
                          <button
                            type="button"
                            onClick={() => void handleCancelScan(scan.id)}
                            disabled={cancellingScanIds.has(scan.id)}
                            className="rounded-full border border-rose-400/30 px-3 py-1 text-xs font-medium text-rose-100 transition hover:bg-rose-400/10 disabled:cursor-not-allowed disabled:opacity-60"
                          >
                            {cancellingScanIds.has(scan.id)
                              ? "Cancelling..."
                              : "Stop Scan"}
                          </button>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}
