"use client";

import { useEffect, useState } from "react";

import { apiClient } from "@/lib/api-client";
import { getSessionUser, isSuperAdmin } from "@/lib/session";
import { Package } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";

type PackageDraft = {
  name: string;
  slug: string;
  scan_limit_per_week: string;
  price_monthly: string;
  status: string;
};

function draftForPackage(item: Package): PackageDraft {
  return {
    name: item.name,
    slug: item.slug,
    scan_limit_per_week: String(item.scan_limit_per_week),
    price_monthly: String(item.price_monthly),
    status: item.status
  };
}

export function PackagesPanel() {
  const [packages, setPackages] = useState<Package[]>([]);
  const [drafts, setDrafts] = useState<Record<number, PackageDraft>>({});
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const superAdmin = isSuperAdmin(getSessionUser());

  async function loadPackages() {
    try {
      setLoading(true);
      setError(null);
      const nextPackages = await apiClient.listPackages();
      setPackages(nextPackages);
      setDrafts(
        Object.fromEntries(
          nextPackages.map((item) => [item.id, draftForPackage(item)])
        )
      );
    } catch {
      setError("Unable to load packages right now.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadPackages();
  }, []);

  function updateDraft(packageId: number, field: keyof PackageDraft, value: string) {
    setDrafts((current) => ({
      ...current,
      [packageId]: {
        ...current[packageId],
        [field]: value
      }
    }));
  }

  async function savePackage(packageId: number) {
    const draft = drafts[packageId];
    if (!draft) {
      return;
    }

    try {
      setSavingId(packageId);
      setError(null);
      await apiClient.updatePackage(packageId, {
        name: draft.name,
        slug: draft.slug,
        scan_limit_per_week: Number(draft.scan_limit_per_week),
        price_monthly: draft.price_monthly,
        status: draft.status
      });
      await loadPackages();
    } catch {
      setError("Unable to save package.");
    } finally {
      setSavingId(null);
    }
  }

  return (
    <section className="rounded-[1.75rem] border border-white/10 bg-white/5 p-6">
      <div className="flex items-center justify-between gap-4">
        <p className="text-sm font-medium text-white">Packages</p>
        <Button variant="secondary" onClick={() => void loadPackages()}>
          Refresh
        </Button>
      </div>
      {loading ? (
        <p className="mt-4 text-sm text-slate-400">Loading packages...</p>
      ) : error ? (
        <p className="mt-4 text-sm text-rose-300">{error}</p>
      ) : (
        <div className="mt-4 grid gap-4 xl:grid-cols-3">
          {packages.map((item) => {
            const draft = drafts[item.id] ?? draftForPackage(item);
            return (
              <div
                key={item.id}
                className="rounded-2xl border border-white/10 bg-slate-950/70 p-5"
              >
                <div className="grid gap-4">
                  <Input
                    label="Name"
                    value={draft.name}
                    onChange={(event) =>
                      updateDraft(item.id, "name", event.target.value)
                    }
                    disabled={!superAdmin}
                  />
                  <Input
                    label="Slug"
                    value={draft.slug}
                    onChange={(event) =>
                      updateDraft(item.id, "slug", event.target.value)
                    }
                    disabled={!superAdmin}
                  />
                  <Input
                    label="Scan limit per week"
                    type="number"
                    min={0}
                    value={draft.scan_limit_per_week}
                    onChange={(event) =>
                      updateDraft(
                        item.id,
                        "scan_limit_per_week",
                        event.target.value
                      )
                    }
                    disabled={!superAdmin}
                  />
                  <Input
                    label="Monthly price"
                    type="number"
                    min={0}
                    step="0.01"
                    value={draft.price_monthly}
                    onChange={(event) =>
                      updateDraft(item.id, "price_monthly", event.target.value)
                    }
                    disabled={!superAdmin}
                  />
                  <Select
                    label="Status"
                    value={draft.status}
                    onChange={(event) =>
                      updateDraft(item.id, "status", event.target.value)
                    }
                    disabled={!superAdmin}
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </Select>
                  {superAdmin ? (
                    <Button
                      onClick={() => void savePackage(item.id)}
                      disabled={savingId === item.id}
                    >
                      {savingId === item.id ? "Saving..." : "Save package"}
                    </Button>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
