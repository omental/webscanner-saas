"use client";

import { useEffect, useState } from "react";

import { CreateUserModal } from "@/components/dashboard/create-user-modal";
import { UsersTable } from "@/components/dashboard/users-table";
import { apiClient } from "@/lib/api-client";
import { Organization, User } from "@/lib/types";
import { getSessionUser, isSuperAdmin } from "@/lib/session";

export function UsersManager() {
  const [users, setUsers] = useState<User[]>([]);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function loadUsers() {
    try {
      setLoading(true);
      setError(null);
      const sessionUser = getSessionUser();
      const [data, nextOrganizations] = await Promise.all([
        apiClient.listUsers(),
        isSuperAdmin(sessionUser) ? apiClient.listOrganizations() : Promise.resolve([])
      ]);
      setUsers(data);
      setOrganizations(nextOrganizations);
    } catch {
      setError("Unable to load users right now.");
    } finally {
      setLoading(false);
    }
  }

  async function handleUpdateUser(
    userId: number,
    payload: {
      name?: string;
      email?: string;
      password?: string;
      role?: string;
      organization_id?: number | null;
      status?: string;
    }
  ) {
    await apiClient.updateUser(userId, payload);
    await loadUsers();
  }

  async function handleDeleteUser(userId: number) {
    await apiClient.deleteUser(userId);
    await loadUsers();
  }

  useEffect(() => {
    void loadUsers();
  }, []);

  return (
    <section className="space-y-6">
      <div className="flex flex-col gap-4 rounded-[1.75rem] border border-white/10 bg-white/5 p-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-sm uppercase tracking-[0.3em] text-cyan-300">
            Team Management
          </p>
          <h3 className="mt-4 text-2xl font-semibold text-white">
            Users and access
          </h3>
          <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-300">
            Create users, update roles and status, or remove accounts.
          </p>
        </div>
        <CreateUserModal onCreated={loadUsers} />
      </div>

      <UsersTable
        users={users}
        loading={loading}
        error={error}
        onRefresh={loadUsers}
        onUpdateUser={handleUpdateUser}
        onDeleteUser={handleDeleteUser}
        organizations={organizations}
      />
    </section>
  );
}
